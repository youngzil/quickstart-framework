#!/bin/bash
export PATH=/app/aideploy/trusthost/sshpass-1.06:$PATH
sshpass -p 1qaz!QAZ ssh -o StrictHostKeyChecking=no aioppf@20.26.37.176 "mkdir -p ~/.ssh;echo ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDFBoh8AaJUolnEUxAfWY7wctUvCBFrPLV7G/QSY7HLudnGxUDNf41gOsP8r69T7hs7gx39UO8gODDD7GAlVtVjyCAAEXWAnMXt6pcro3AEJufbIkSZsnIUpvHtbtXlZQ+2/P8nJ0rAjmzzh1sZd27n8itIWeZHMMGhC0JWrzW0+HhOMoLW9gIFElhoJcnynHMQdDWre9A77OhdwwNH0juRUkQLtfYofeC8ZLmfske+hq1dVfDjhIclz51y4KmIu7AXvJ3s9C/vatdrz+v2E3ti2WAOz4C/Cki7RReA3CZkwEZiy+PNW5Gh658WT4NeXY4hFrTMV5+pxBWmMQGWs9IN aideploy@csv-apiwg02 >~/.ssh/authorized_keys;chmod 700 .ssh;chmod 600 .ssh/authorized_keys " &>/dev/null
 
	 if [ $? -eq 0 ];then
   		   echo   Deploying pub_key for aioppf@20.26.37.176......Success! /bin/true
	   else
			echo  Deploying pub_key for aioppf@20.26.37.176......Failed! /bin/false
	   fi

sshpass -p 1qaz!QAZ ssh -o StrictHostKeyChecking=no memdb@20.26.37.176 "mkdir -p ~/.ssh;echo ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDFBoh8AaJUolnEUxAfWY7wctUvCBFrPLV7G/QSY7HLudnGxUDNf41gOsP8r69T7hs7gx39UO8gODDD7GAlVtVjyCAAEXWAnMXt6pcro3AEJufbIkSZsnIUpvHtbtXlZQ+2/P8nJ0rAjmzzh1sZd27n8itIWeZHMMGhC0JWrzW0+HhOMoLW9gIFElhoJcnynHMQdDWre9A77OhdwwNH0juRUkQLtfYofeC8ZLmfske+hq1dVfDjhIclz51y4KmIu7AXvJ3s9C/vatdrz+v2E3ti2WAOz4C/Cki7RReA3CZkwEZiy+PNW5Gh658WT4NeXY4hFrTMV5+pxBWmMQGWs9IN aideploy@csv-apiwg02 >~/.ssh/authorized_keys;chmod 700 .ssh;chmod 600 .ssh/authorized_keys " &>/dev/null
 
	 if [ $? -eq 0 ];then
   		   echo   Deploying pub_key for memdb@20.26.37.176......Success! /bin/true
	   else
			echo  Deploying pub_key for memdb@20.26.37.176......Failed! /bin/false
	   fi

sshpass -p 1qaz!QAZ ssh -o StrictHostKeyChecking=no aiftp@20.26.37.176 "mkdir -p ~/.ssh;echo ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDFBoh8AaJUolnEUxAfWY7wctUvCBFrPLV7G/QSY7HLudnGxUDNf41gOsP8r69T7hs7gx39UO8gODDD7GAlVtVjyCAAEXWAnMXt6pcro3AEJufbIkSZsnIUpvHtbtXlZQ+2/P8nJ0rAjmzzh1sZd27n8itIWeZHMMGhC0JWrzW0+HhOMoLW9gIFElhoJcnynHMQdDWre9A77OhdwwNH0juRUkQLtfYofeC8ZLmfske+hq1dVfDjhIclz51y4KmIu7AXvJ3s9C/vatdrz+v2E3ti2WAOz4C/Cki7RReA3CZkwEZiy+PNW5Gh658WT4NeXY4hFrTMV5+pxBWmMQGWs9IN aideploy@csv-apiwg02 >~/.ssh/authorized_keys;chmod 700 .ssh;chmod 600 .ssh/authorized_keys " &>/dev/null
 
	 if [ $? -eq 0 ];then
   		   echo   Deploying pub_key for aiftp@20.26.37.176......Success! /bin/true
	   else
			echo  Deploying pub_key for aiftp@20.26.37.176......Failed! /bin/false
	   fi

sshpass -p 1qaz!QAZ ssh -o StrictHostKeyChecking=no nginx@20.26.37.176 "mkdir -p ~/.ssh;echo ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDFBoh8AaJUolnEUxAfWY7wctUvCBFrPLV7G/QSY7HLudnGxUDNf41gOsP8r69T7hs7gx39UO8gODDD7GAlVtVjyCAAEXWAnMXt6pcro3AEJufbIkSZsnIUpvHtbtXlZQ+2/P8nJ0rAjmzzh1sZd27n8itIWeZHMMGhC0JWrzW0+HhOMoLW9gIFElhoJcnynHMQdDWre9A77OhdwwNH0juRUkQLtfYofeC8ZLmfske+hq1dVfDjhIclz51y4KmIu7AXvJ3s9C/vatdrz+v2E3ti2WAOz4C/Cki7RReA3CZkwEZiy+PNW5Gh658WT4NeXY4hFrTMV5+pxBWmMQGWs9IN aideploy@csv-apiwg02 >~/.ssh/authorized_keys;chmod 700 .ssh;chmod 600 .ssh/authorized_keys " &>/dev/null
 
	 if [ $? -eq 0 ];then
   		   echo   Deploying pub_key for nginx@20.26.37.176......Success! /bin/true
	   else
			echo  Deploying pub_key for nginx@20.26.37.176......Failed! /bin/false
	   fi

sshpass -p 1qaz!QAZ ssh -o StrictHostKeyChecking=no aioppf@20.26.37.177 "mkdir -p ~/.ssh;echo ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDFBoh8AaJUolnEUxAfWY7wctUvCBFrPLV7G/QSY7HLudnGxUDNf41gOsP8r69T7hs7gx39UO8gODDD7GAlVtVjyCAAEXWAnMXt6pcro3AEJufbIkSZsnIUpvHtbtXlZQ+2/P8nJ0rAjmzzh1sZd27n8itIWeZHMMGhC0JWrzW0+HhOMoLW9gIFElhoJcnynHMQdDWre9A77OhdwwNH0juRUkQLtfYofeC8ZLmfske+hq1dVfDjhIclz51y4KmIu7AXvJ3s9C/vatdrz+v2E3ti2WAOz4C/Cki7RReA3CZkwEZiy+PNW5Gh658WT4NeXY4hFrTMV5+pxBWmMQGWs9IN aideploy@csv-apiwg02 >~/.ssh/authorized_keys;chmod 700 .ssh;chmod 600 .ssh/authorized_keys " &>/dev/null
 
	 if [ $? -eq 0 ];then
   		   echo   Deploying pub_key for aioppf@20.26.37.177......Success! /bin/true
	   else
			echo  Deploying pub_key for aioppf@20.26.37.177......Failed! /bin/false
	   fi

sshpass -p 1qaz!QAZ ssh -o StrictHostKeyChecking=no aideploy@20.26.37.177 "mkdir -p ~/.ssh;echo ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDFBoh8AaJUolnEUxAfWY7wctUvCBFrPLV7G/QSY7HLudnGxUDNf41gOsP8r69T7hs7gx39UO8gODDD7GAlVtVjyCAAEXWAnMXt6pcro3AEJufbIkSZsnIUpvHtbtXlZQ+2/P8nJ0rAjmzzh1sZd27n8itIWeZHMMGhC0JWrzW0+HhOMoLW9gIFElhoJcnynHMQdDWre9A77OhdwwNH0juRUkQLtfYofeC8ZLmfske+hq1dVfDjhIclz51y4KmIu7AXvJ3s9C/vatdrz+v2E3ti2WAOz4C/Cki7RReA3CZkwEZiy+PNW5Gh658WT4NeXY4hFrTMV5+pxBWmMQGWs9IN aideploy@csv-apiwg02 >~/.ssh/authorized_keys;chmod 700 .ssh;chmod 600 .ssh/authorized_keys " &>/dev/null
 
	 if [ $? -eq 0 ];then
   		   echo   Deploying pub_key for aideploy@20.26.37.177......Success! /bin/true
	   else
			echo  Deploying pub_key for aideploy@20.26.37.177......Failed! /bin/false
	   fi

sshpass -p 1qaz!QAZ ssh -o StrictHostKeyChecking=no memdb@20.26.37.177 "mkdir -p ~/.ssh;echo ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDFBoh8AaJUolnEUxAfWY7wctUvCBFrPLV7G/QSY7HLudnGxUDNf41gOsP8r69T7hs7gx39UO8gODDD7GAlVtVjyCAAEXWAnMXt6pcro3AEJufbIkSZsnIUpvHtbtXlZQ+2/P8nJ0rAjmzzh1sZd27n8itIWeZHMMGhC0JWrzW0+HhOMoLW9gIFElhoJcnynHMQdDWre9A77OhdwwNH0juRUkQLtfYofeC8ZLmfske+hq1dVfDjhIclz51y4KmIu7AXvJ3s9C/vatdrz+v2E3ti2WAOz4C/Cki7RReA3CZkwEZiy+PNW5Gh658WT4NeXY4hFrTMV5+pxBWmMQGWs9IN aideploy@csv-apiwg02 >~/.ssh/authorized_keys;chmod 700 .ssh;chmod 600 .ssh/authorized_keys " &>/dev/null
 
	 if [ $? -eq 0 ];then
   		   echo   Deploying pub_key for memdb@20.26.37.177......Success! /bin/true
	   else
			echo  Deploying pub_key for memdb@20.26.37.177......Failed! /bin/false
	   fi

sshpass -p 1qaz!QAZ ssh -o StrictHostKeyChecking=no aiauth@20.26.37.177 "mkdir -p ~/.ssh;echo ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDFBoh8AaJUolnEUxAfWY7wctUvCBFrPLV7G/QSY7HLudnGxUDNf41gOsP8r69T7hs7gx39UO8gODDD7GAlVtVjyCAAEXWAnMXt6pcro3AEJufbIkSZsnIUpvHtbtXlZQ+2/P8nJ0rAjmzzh1sZd27n8itIWeZHMMGhC0JWrzW0+HhOMoLW9gIFElhoJcnynHMQdDWre9A77OhdwwNH0juRUkQLtfYofeC8ZLmfske+hq1dVfDjhIclz51y4KmIu7AXvJ3s9C/vatdrz+v2E3ti2WAOz4C/Cki7RReA3CZkwEZiy+PNW5Gh658WT4NeXY4hFrTMV5+pxBWmMQGWs9IN aideploy@csv-apiwg02 >~/.ssh/authorized_keys;chmod 700 .ssh;chmod 600 .ssh/authorized_keys " &>/dev/null
 
	 if [ $? -eq 0 ];then
   		   echo   Deploying pub_key for aiauth@20.26.37.177......Success! /bin/true
	   else
			echo  Deploying pub_key for aiauth@20.26.37.177......Failed! /bin/false
	   fi

sshpass -p 1qaz!QAZ ssh -o StrictHostKeyChecking=no aioppf@20.26.37.178 "mkdir -p ~/.ssh;echo ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDFBoh8AaJUolnEUxAfWY7wctUvCBFrPLV7G/QSY7HLudnGxUDNf41gOsP8r69T7hs7gx39UO8gODDD7GAlVtVjyCAAEXWAnMXt6pcro3AEJufbIkSZsnIUpvHtbtXlZQ+2/P8nJ0rAjmzzh1sZd27n8itIWeZHMMGhC0JWrzW0+HhOMoLW9gIFElhoJcnynHMQdDWre9A77OhdwwNH0juRUkQLtfYofeC8ZLmfske+hq1dVfDjhIclz51y4KmIu7AXvJ3s9C/vatdrz+v2E3ti2WAOz4C/Cki7RReA3CZkwEZiy+PNW5Gh658WT4NeXY4hFrTMV5+pxBWmMQGWs9IN aideploy@csv-apiwg02 >~/.ssh/authorized_keys;chmod 700 .ssh;chmod 600 .ssh/authorized_keys " &>/dev/null
 
	 if [ $? -eq 0 ];then
   		   echo   Deploying pub_key for aioppf@20.26.37.178......Success! /bin/true
	   else
			echo  Deploying pub_key for aioppf@20.26.37.178......Failed! /bin/false
	   fi

sshpass -p 1qaz!QAZ ssh -o StrictHostKeyChecking=no memdb@20.26.37.178 "mkdir -p ~/.ssh;echo ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDFBoh8AaJUolnEUxAfWY7wctUvCBFrPLV7G/QSY7HLudnGxUDNf41gOsP8r69T7hs7gx39UO8gODDD7GAlVtVjyCAAEXWAnMXt6pcro3AEJufbIkSZsnIUpvHtbtXlZQ+2/P8nJ0rAjmzzh1sZd27n8itIWeZHMMGhC0JWrzW0+HhOMoLW9gIFElhoJcnynHMQdDWre9A77OhdwwNH0juRUkQLtfYofeC8ZLmfske+hq1dVfDjhIclz51y4KmIu7AXvJ3s9C/vatdrz+v2E3ti2WAOz4C/Cki7RReA3CZkwEZiy+PNW5Gh658WT4NeXY4hFrTMV5+pxBWmMQGWs9IN aideploy@csv-apiwg02 >~/.ssh/authorized_keys;chmod 700 .ssh;chmod 600 .ssh/authorized_keys " &>/dev/null
 
	 if [ $? -eq 0 ];then
   		   echo   Deploying pub_key for memdb@20.26.37.178......Success! /bin/true
	   else
			echo  Deploying pub_key for memdb@20.26.37.178......Failed! /bin/false
	   fi

sshpass -p 1qaz!QAZ ssh -o StrictHostKeyChecking=no aitask@20.26.37.178 "mkdir -p ~/.ssh;echo ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDFBoh8AaJUolnEUxAfWY7wctUvCBFrPLV7G/QSY7HLudnGxUDNf41gOsP8r69T7hs7gx39UO8gODDD7GAlVtVjyCAAEXWAnMXt6pcro3AEJufbIkSZsnIUpvHtbtXlZQ+2/P8nJ0rAjmzzh1sZd27n8itIWeZHMMGhC0JWrzW0+HhOMoLW9gIFElhoJcnynHMQdDWre9A77OhdwwNH0juRUkQLtfYofeC8ZLmfske+hq1dVfDjhIclz51y4KmIu7AXvJ3s9C/vatdrz+v2E3ti2WAOz4C/Cki7RReA3CZkwEZiy+PNW5Gh658WT4NeXY4hFrTMV5+pxBWmMQGWs9IN aideploy@csv-apiwg02 >~/.ssh/authorized_keys;chmod 700 .ssh;chmod 600 .ssh/authorized_keys " &>/dev/null
 
	 if [ $? -eq 0 ];then
   		   echo   Deploying pub_key for aitask@20.26.37.178......Success! /bin/true
	   else
			echo  Deploying pub_key for aitask@20.26.37.178......Failed! /bin/false
	   fi

sshpass -p 1qaz!QAZ ssh -o StrictHostKeyChecking=no aiesb@20.26.37.179 "mkdir -p ~/.ssh;echo ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDFBoh8AaJUolnEUxAfWY7wctUvCBFrPLV7G/QSY7HLudnGxUDNf41gOsP8r69T7hs7gx39UO8gODDD7GAlVtVjyCAAEXWAnMXt6pcro3AEJufbIkSZsnIUpvHtbtXlZQ+2/P8nJ0rAjmzzh1sZd27n8itIWeZHMMGhC0JWrzW0+HhOMoLW9gIFElhoJcnynHMQdDWre9A77OhdwwNH0juRUkQLtfYofeC8ZLmfske+hq1dVfDjhIclz51y4KmIu7AXvJ3s9C/vatdrz+v2E3ti2WAOz4C/Cki7RReA3CZkwEZiy+PNW5Gh658WT4NeXY4hFrTMV5+pxBWmMQGWs9IN aideploy@csv-apiwg02 >~/.ssh/authorized_keys;chmod 700 .ssh;chmod 600 .ssh/authorized_keys " &>/dev/null
 
	 if [ $? -eq 0 ];then
   		   echo   Deploying pub_key for aiesb@20.26.37.179......Success! /bin/true
	   else
			echo  Deploying pub_key for aiesb@20.26.37.179......Failed! /bin/false
	   fi

sshpass -p 1qaz!QAZ ssh -o StrictHostKeyChecking=no esbsx@20.26.37.179 "mkdir -p ~/.ssh;echo ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDFBoh8AaJUolnEUxAfWY7wctUvCBFrPLV7G/QSY7HLudnGxUDNf41gOsP8r69T7hs7gx39UO8gODDD7GAlVtVjyCAAEXWAnMXt6pcro3AEJufbIkSZsnIUpvHtbtXlZQ+2/P8nJ0rAjmzzh1sZd27n8itIWeZHMMGhC0JWrzW0+HhOMoLW9gIFElhoJcnynHMQdDWre9A77OhdwwNH0juRUkQLtfYofeC8ZLmfske+hq1dVfDjhIclz51y4KmIu7AXvJ3s9C/vatdrz+v2E3ti2WAOz4C/Cki7RReA3CZkwEZiy+PNW5Gh658WT4NeXY4hFrTMV5+pxBWmMQGWs9IN aideploy@csv-apiwg02 >~/.ssh/authorized_keys;chmod 700 .ssh;chmod 600 .ssh/authorized_keys " &>/dev/null
 
	 if [ $? -eq 0 ];then
   		   echo   Deploying pub_key for esbsx@20.26.37.179......Success! /bin/true
	   else
			echo  Deploying pub_key for esbsx@20.26.37.179......Failed! /bin/false
	   fi

sshpass -p 1qaz!QAZ ssh -o StrictHostKeyChecking=no redis@20.26.37.179 "mkdir -p ~/.ssh;echo ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDFBoh8AaJUolnEUxAfWY7wctUvCBFrPLV7G/QSY7HLudnGxUDNf41gOsP8r69T7hs7gx39UO8gODDD7GAlVtVjyCAAEXWAnMXt6pcro3AEJufbIkSZsnIUpvHtbtXlZQ+2/P8nJ0rAjmzzh1sZd27n8itIWeZHMMGhC0JWrzW0+HhOMoLW9gIFElhoJcnynHMQdDWre9A77OhdwwNH0juRUkQLtfYofeC8ZLmfske+hq1dVfDjhIclz51y4KmIu7AXvJ3s9C/vatdrz+v2E3ti2WAOz4C/Cki7RReA3CZkwEZiy+PNW5Gh658WT4NeXY4hFrTMV5+pxBWmMQGWs9IN aideploy@csv-apiwg02 >~/.ssh/authorized_keys;chmod 700 .ssh;chmod 600 .ssh/authorized_keys " &>/dev/null
 
	 if [ $? -eq 0 ];then
   		   echo   Deploying pub_key for redis@20.26.37.179......Success! /bin/true
	   else
			echo  Deploying pub_key for redis@20.26.37.179......Failed! /bin/false
	   fi

sshpass -p 1qaz!QAZ ssh -o StrictHostKeyChecking=no aiesb@20.26.37.180 "mkdir -p ~/.ssh;echo ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDFBoh8AaJUolnEUxAfWY7wctUvCBFrPLV7G/QSY7HLudnGxUDNf41gOsP8r69T7hs7gx39UO8gODDD7GAlVtVjyCAAEXWAnMXt6pcro3AEJufbIkSZsnIUpvHtbtXlZQ+2/P8nJ0rAjmzzh1sZd27n8itIWeZHMMGhC0JWrzW0+HhOMoLW9gIFElhoJcnynHMQdDWre9A77OhdwwNH0juRUkQLtfYofeC8ZLmfske+hq1dVfDjhIclz51y4KmIu7AXvJ3s9C/vatdrz+v2E3ti2WAOz4C/Cki7RReA3CZkwEZiy+PNW5Gh658WT4NeXY4hFrTMV5+pxBWmMQGWs9IN aideploy@csv-apiwg02 >~/.ssh/authorized_keys;chmod 700 .ssh;chmod 600 .ssh/authorized_keys " &>/dev/null
 
	 if [ $? -eq 0 ];then
   		   echo   Deploying pub_key for aiesb@20.26.37.180......Success! /bin/true
	   else
			echo  Deploying pub_key for aiesb@20.26.37.180......Failed! /bin/false
	   fi

sshpass -p 1qaz!QAZ ssh -o StrictHostKeyChecking=no aopgateway@20.26.37.180 "mkdir -p ~/.ssh;echo ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDFBoh8AaJUolnEUxAfWY7wctUvCBFrPLV7G/QSY7HLudnGxUDNf41gOsP8r69T7hs7gx39UO8gODDD7GAlVtVjyCAAEXWAnMXt6pcro3AEJufbIkSZsnIUpvHtbtXlZQ+2/P8nJ0rAjmzzh1sZd27n8itIWeZHMMGhC0JWrzW0+HhOMoLW9gIFElhoJcnynHMQdDWre9A77OhdwwNH0juRUkQLtfYofeC8ZLmfske+hq1dVfDjhIclz51y4KmIu7AXvJ3s9C/vatdrz+v2E3ti2WAOz4C/Cki7RReA3CZkwEZiy+PNW5Gh658WT4NeXY4hFrTMV5+pxBWmMQGWs9IN aideploy@csv-apiwg02 >~/.ssh/authorized_keys;chmod 700 .ssh;chmod 600 .ssh/authorized_keys " &>/dev/null
 
	 if [ $? -eq 0 ];then
   		   echo   Deploying pub_key for aopgateway@20.26.37.180......Success! /bin/true
	   else
			echo  Deploying pub_key for aopgateway@20.26.37.180......Failed! /bin/false
	   fi

sshpass -p 1qaz!QAZ ssh -o StrictHostKeyChecking=no redis@20.26.37.180 "mkdir -p ~/.ssh;echo ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDFBoh8AaJUolnEUxAfWY7wctUvCBFrPLV7G/QSY7HLudnGxUDNf41gOsP8r69T7hs7gx39UO8gODDD7GAlVtVjyCAAEXWAnMXt6pcro3AEJufbIkSZsnIUpvHtbtXlZQ+2/P8nJ0rAjmzzh1sZd27n8itIWeZHMMGhC0JWrzW0+HhOMoLW9gIFElhoJcnynHMQdDWre9A77OhdwwNH0juRUkQLtfYofeC8ZLmfske+hq1dVfDjhIclz51y4KmIu7AXvJ3s9C/vatdrz+v2E3ti2WAOz4C/Cki7RReA3CZkwEZiy+PNW5Gh658WT4NeXY4hFrTMV5+pxBWmMQGWs9IN aideploy@csv-apiwg02 >~/.ssh/authorized_keys;chmod 700 .ssh;chmod 600 .ssh/authorized_keys " &>/dev/null
 
	 if [ $? -eq 0 ];then
   		   echo   Deploying pub_key for redis@20.26.37.180......Success! /bin/true
	   else
			echo  Deploying pub_key for redis@20.26.37.180......Failed! /bin/false
	   fi

sshpass -p 1qaz!QAZ ssh -o StrictHostKeyChecking=no aiesb@20.26.37.181 "mkdir -p ~/.ssh;echo ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDFBoh8AaJUolnEUxAfWY7wctUvCBFrPLV7G/QSY7HLudnGxUDNf41gOsP8r69T7hs7gx39UO8gODDD7GAlVtVjyCAAEXWAnMXt6pcro3AEJufbIkSZsnIUpvHtbtXlZQ+2/P8nJ0rAjmzzh1sZd27n8itIWeZHMMGhC0JWrzW0+HhOMoLW9gIFElhoJcnynHMQdDWre9A77OhdwwNH0juRUkQLtfYofeC8ZLmfske+hq1dVfDjhIclz51y4KmIu7AXvJ3s9C/vatdrz+v2E3ti2WAOz4C/Cki7RReA3CZkwEZiy+PNW5Gh658WT4NeXY4hFrTMV5+pxBWmMQGWs9IN aideploy@csv-apiwg02 >~/.ssh/authorized_keys;chmod 700 .ssh;chmod 600 .ssh/authorized_keys " &>/dev/null
 
	 if [ $? -eq 0 ];then
   		   echo   Deploying pub_key for aiesb@20.26.37.181......Success! /bin/true
	   else
			echo  Deploying pub_key for aiesb@20.26.37.181......Failed! /bin/false
	   fi

sshpass -p 1qaz!QAZ ssh -o StrictHostKeyChecking=no redis@20.26.37.181 "mkdir -p ~/.ssh;echo ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDFBoh8AaJUolnEUxAfWY7wctUvCBFrPLV7G/QSY7HLudnGxUDNf41gOsP8r69T7hs7gx39UO8gODDD7GAlVtVjyCAAEXWAnMXt6pcro3AEJufbIkSZsnIUpvHtbtXlZQ+2/P8nJ0rAjmzzh1sZd27n8itIWeZHMMGhC0JWrzW0+HhOMoLW9gIFElhoJcnynHMQdDWre9A77OhdwwNH0juRUkQLtfYofeC8ZLmfske+hq1dVfDjhIclz51y4KmIu7AXvJ3s9C/vatdrz+v2E3ti2WAOz4C/Cki7RReA3CZkwEZiy+PNW5Gh658WT4NeXY4hFrTMV5+pxBWmMQGWs9IN aideploy@csv-apiwg02 >~/.ssh/authorized_keys;chmod 700 .ssh;chmod 600 .ssh/authorized_keys " &>/dev/null
 
	 if [ $? -eq 0 ];then
   		   echo   Deploying pub_key for redis@20.26.37.181......Success! /bin/true
	   else
			echo  Deploying pub_key for redis@20.26.37.181......Failed! /bin/false
	   fi

